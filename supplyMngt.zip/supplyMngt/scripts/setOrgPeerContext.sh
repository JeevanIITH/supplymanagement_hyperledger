#!/bin/bash

# import utils
source scripts/envVar.sh

ORG=$1

setGlobals $ORG